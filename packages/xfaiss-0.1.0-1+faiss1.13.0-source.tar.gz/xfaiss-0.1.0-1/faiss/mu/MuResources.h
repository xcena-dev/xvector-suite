/*
   Copyright (c) 2026 XCENA Inc.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

#ifndef FAISS_MU_RESOURCES_H
#define FAISS_MU_RESOURCES_H

#include <cstdint>
#include <memory>
#include <optional>
#include <string>

#include <xvector_cpp/xvec_context.hpp>

namespace faiss {

/// Configuration for MuResources
///
/// By default, values are loaded from xvec::host::ConfigManager which reads
/// from environment variables. Use MuResourcesConfig::fromConfigManager() to
/// create a config with all values populated from the global ConfigManager.
struct MuResourcesConfig {
    uint32_t deviceId = 0;
    std::string modulePath;
    uint32_t numSub = 1;
    uint32_t taskCount = 1;
    uint32_t deviceLogLevel = 0;

    /// Enable the default log sink that prints xvector logs to stdout.
    /// Set to true to use the built-in log handler.
    bool enableDefaultLogSink = false;

    /// Create a config populated from xvec::host::ConfigManager.
    /// This reads values from environment variables with the following mapping:
    /// - XVECTOR_MUBIN_PATH -> modulePath
    /// - DEVICEID -> deviceId
    /// - NUMSUB -> numSub
    /// - TASKCOUNT -> taskCount
    /// - LOGDEVICE -> deviceLogLevel (0=NONE, 1=ERROR, ..., 5=TRACE)
    /// - LOGHOST -> enableDefaultLogSink
    static MuResourcesConfig fromConfigManager();
};

/// RAII wrapper for xvector execution context
///
/// This class manages the lifecycle of an xvector context and can be
/// shared across multiple MuIndex instances via shared_ptr.
class MuResources {
   public:
    explicit MuResources(const MuResourcesConfig& config);

    // Non-copyable (xvec::Context is non-copyable)
    MuResources(const MuResources&) = delete;
    MuResources& operator=(const MuResources&) = delete;

    // Movable (defaulted — xvec::Context supports move)
    MuResources(MuResources&&) = default;
    MuResources& operator=(MuResources&&) = default;

    xvecExecutionContextTag* context() const {
        return context_->handle();
    }

    /// Get the configuration
    const MuResourcesConfig& config() const {
        return config_;
    }

   private:
    MuResourcesConfig config_;
    std::optional<xvec::Context> context_;
};

/// Convenience function to create a shared MuResources using ConfigManager
/// This is the recommended way to create MuResources with default configuration
std::shared_ptr<MuResources> makeMuResources();

/// Convenience function to create a shared MuResources with custom config
std::shared_ptr<MuResources> makeMuResources(const MuResourcesConfig& config);

} // namespace faiss

#endif
