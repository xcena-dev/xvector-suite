/*
   Copyright (c) 2026 XCENA Inc.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

#include <faiss/IndexFlat.h>
#include <faiss/impl/FaissAssert.h>
#include <faiss/mu/MuIndexIvfRabitq.h>

#include <pxl/pxl.hpp>

#include <xvector/xvec_ivf_rabitq.h>

#include <iomanip>
#include <iostream>

// xvecIvfRaBitQSearchTiming definition
// Must match xvector's search_timing.hpp xvecIvfRaBitQSearchTiming exactly.
struct xvecIvfRaBitQSearchTiming {
    int64_t indexLoadUs = 0;
    int64_t indexPrepareUs = 0;
    int64_t indexFlushUs = 0;
    int64_t coarseSearchUs = 0;
    int64_t queryPrepareUs = 0;
    int64_t queryFlushUs = 0;
    int64_t kernelExecutionUs = 0;
    int64_t totalUs = 0;
};

#include <faiss/mu/MuTimer.h>

#include <algorithm>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <optional>
#include <utility>
#include <vector>

#include <omp.h>

namespace faiss {

MuIndexIvfRabitq::MuIndexIvfRabitq(
        std::shared_ptr<MuResources> resources,
        Index* quantizer,
        size_t d,
        size_t nlist,
        MetricType metric)
        : IndexIVFRaBitQ(quantizer, d, nlist, metric),
          resources_(std::move(resources)) {}

MuIndexIvfRabitq::MuIndexIvfRabitq(
        std::shared_ptr<MuResources> resources,
        const faiss::IndexIVFRaBitQ* index)
        : IndexIVFRaBitQ(*index), resources_(std::move(resources)) {
    // Shallow copy shares quantizer/invlists pointers with the original.
    // Ownership stays with the original — we only borrow them.
    own_fields = false;
    own_invlists = false;
}

MuIndexIvfRabitq::~MuIndexIvfRabitq() = default;

xvecDistanceType MuIndexIvfRabitq::convertMetricType_() const {
    switch (metric_type) {
        case METRIC_INNER_PRODUCT:
            return XVEC_DISTANCE_DOT_PRODUCT;
        case METRIC_L2:
            return XVEC_DISTANCE_L2;
        default:
            // Default to L2 for unsupported metrics
            return XVEC_DISTANCE_L2;
    }
}

void MuIndexIvfRabitq::syncToMuDevice() {
    FAISS_THROW_IF_NOT(is_trained);
    FAISS_THROW_IF_NOT(ntotal > 0);
    FAISS_THROW_IF_NOT(resources_ != nullptr);

    // Destroy existing MU index if present, then reload
    muIndex_.reset();
    auto* ctx = resources_->context();
    muIndex_.emplace(xvec::IvfRaBitQIndex::fromFaissIndex(
            ctx, static_cast<void*>(this)));
}

xvec::Buffer MuIndexIvfRabitq::createQueryBuffer_(
        xvecExecutionContextTag* ctx,
        idx_t n,
        const float* x) const {
    size_t queryBufferSize = static_cast<size_t>(n) * d * sizeof(float);
    xvec::Buffer queryBuffer(ctx, queryBufferSize);

    auto* queryData = queryBuffer.data();
    std::memcpy(queryData, x, queryBufferSize);
    pxl::flushHostCache(queryData, queryBufferSize);

    return queryBuffer;
}

void MuIndexIvfRabitq::copyResultsToOutput_(
        const xvecIvfRaBitQSearchResultFloat32* muResults,
        idx_t n,
        idx_t k,
        float* distances,
        idx_t* labels) const {
    for (idx_t queryIdx = 0; queryIdx < n; ++queryIdx) {
        idx_t outputOffset = queryIdx * k;
        for (idx_t i = 0; i < k; ++i) {
            const auto& result = muResults[outputOffset + i];

            float faissDistance = result.score;
            if (metric_type == METRIC_INNER_PRODUCT) {
                faissDistance = -faissDistance;
            }

            distances[outputOffset + i] = faissDistance;
            labels[outputOffset + i] = static_cast<idx_t>(result.vectorId);
        }
    }
}

xvec::Buffer MuIndexIvfRabitq::createClustersBuffer_(
        xvecExecutionContextTag* ctx,
        idx_t n,
        size_t nprobe,
        const idx_t* assign) const {
    size_t clustersBufferSize =
            static_cast<size_t>(n) * nprobe * sizeof(xvecClusterIdType);
    xvec::Buffer clustersBuffer(ctx, clustersBufferSize);

    auto* clusterIds = clustersBuffer.data<xvecClusterIdType>();
    for (idx_t i = 0; i < n * static_cast<idx_t>(nprobe); ++i) {
        clusterIds[i] = static_cast<xvecClusterIdType>(assign[i]);
    }
    pxl::flushHostCache(clusterIds, clustersBufferSize);

    return clustersBuffer;
}

void MuIndexIvfRabitq::search(
        idx_t n,
        const float* x,
        idx_t k,
        float* distances,
        idx_t* labels,
        const SearchParameters* params) const {
    double total_ms = 0, coarse_ms = 0, fine_ms = 0;
    ScopedTimer total_timer(total_ms);

    FAISS_THROW_IF_NOT(is_trained);
    FAISS_THROW_IF_NOT(ntotal > 0);
    FAISS_THROW_IF_NOT(resources_ != nullptr);
    FAISS_THROW_IF_NOT_MSG(
            muIndex_.has_value(),
            "MU index not initialized. "
            "Call syncToMuDevice() after adding vectors to sync the index to MU device.");

    // Get nprobe from params or use default
    size_t nprobe_to_use = nprobe;
    const IVFSearchParameters* ivf_params = nullptr;
    if (params) {
        ivf_params = dynamic_cast<const IVFSearchParameters*>(params);
        if (ivf_params && ivf_params->nprobe > 0) {
            nprobe_to_use = ivf_params->nprobe;
        }
    }

    // === Coarse search: use quantizer to find nearest clusters ===
    // Parallel slicing strategy (same as IndexIVF::search) to avoid
    // a single large GEMM that thrashes CPU caches.
    std::vector<idx_t> coarse_labels(n * nprobe_to_use);
    std::vector<float> coarse_distances(n * nprobe_to_use);
    {
        ScopedTimer t(coarse_ms);
        // Cap at 64 to stay within OpenBLAS thread-region limits
        // (each OMP thread calls into BLAS during quantizer->search).
        int nt = std::min({omp_get_max_threads(), int(n), 64});
        std::mutex exception_mutex;
        std::string exception_string;

#pragma omp parallel for if (nt > 1)
        for (int slice = 0; slice < nt; slice++) {
            idx_t i0 = n * slice / nt;
            idx_t i1 = n * (slice + 1) / nt;
            if (i1 > i0) {
                try {
                    quantizer->search(
                            i1 - i0,
                            x + i0 * d,
                            nprobe_to_use,
                            coarse_distances.data() + i0 * nprobe_to_use,
                            coarse_labels.data() + i0 * nprobe_to_use);
                } catch (const std::exception& e) {
                    std::lock_guard<std::mutex> lock(exception_mutex);
                    exception_string = e.what();
                }
            }
        }

        if (!exception_string.empty()) {
            FAISS_THROW_MSG(exception_string.c_str());
        }
    }

    // === Fine search: use xvector with preassigned clusters ===
    {
        ScopedTimer t(fine_ms);
        search_preassigned(
                n,
                x,
                k,
                coarse_labels.data(),
                coarse_distances.data(),
                distances,
                labels,
                false,
                ivf_params,
                nullptr);
    }

    std::cout << std::fixed << std::setprecision(2)
              << "[MuIndexIvfRabitq::search] n=" << n
              << " k=" << k << " nprobe=" << nprobe_to_use << "\n"
              << "    coarse      " << std::setw(10) << coarse_ms << " ms\n"
              << "    fine        " << std::setw(10) << fine_ms << " ms\n"
              << "    total       " << std::setw(10) << total_timer.elapsedMs() << " ms\n";
}

void MuIndexIvfRabitq::search_preassigned(
        idx_t n,
        const float* x,
        idx_t k,
        const idx_t* assign,
        const float* centroid_dis,
        float* distances,
        idx_t* labels,
        bool store_pairs,
        const IVFSearchParameters* params,
        IndexIVFStats* stats) const {
    double total_ms = 0, buf_ms = 0, search_ms = 0, copy_ms = 0;
    ScopedTimer total_timer(total_ms);

    FAISS_THROW_IF_NOT(is_trained);
    FAISS_THROW_IF_NOT(ntotal > 0);
    FAISS_THROW_IF_NOT(resources_ != nullptr);
    FAISS_THROW_IF_NOT_MSG(
            muIndex_.has_value(),
            "MU index not initialized. "
            "Call syncToMuDevice() after adding vectors to sync the index to MU device.");

    size_t nprobe_to_use = nprobe;
    uint8_t qb_to_use = qb;
    bool centered = false;

    if (params) {
        if (params->nprobe > 0) {
            nprobe_to_use = params->nprobe;
        }
        const auto* rabitq_params =
                dynamic_cast<const IVFRaBitQSearchParameters*>(params);
        if (rabitq_params) {
            qb_to_use = rabitq_params->qb;
            centered = rabitq_params->centered;
        }
    }

    auto* ctx = resources_->context();

    // Create buffers
    std::optional<xvec::Buffer> queryBuffer;
    std::optional<xvec::Buffer> clustersBuffer;
    std::optional<xvec::Buffer> resultsBuffer;
    {
        ScopedTimer t(buf_ms);
        queryBuffer.emplace(createQueryBuffer_(ctx, n, x));
        clustersBuffer.emplace(
                createClustersBuffer_(ctx, n, nprobe_to_use, assign));

        size_t resultsBufferSize = static_cast<size_t>(n) * k *
                sizeof(xvecIvfRaBitQSearchResultFloat32);
        resultsBuffer.emplace(ctx, resultsBufferSize);
    }

    // Build fine search query
    xvecIvfRaBitQFineSearchQueryFloat32 fineSearchQuery{};
    fineSearchQuery.version = 1;
    fineSearchQuery.structSize = sizeof(xvecIvfRaBitQFineSearchQueryFloat32);
    fineSearchQuery.dimension = static_cast<xvecDimensionType>(d);
    fineSearchQuery.queryVectorCount = static_cast<xvecVectorIdType>(n);
    fineSearchQuery.queryVectorsBufferHandle = queryBuffer->handle();
    fineSearchQuery.topK = static_cast<xvecTopKType>(k);
    fineSearchQuery.distanceType = convertMetricType_();
    fineSearchQuery.numProbesPerQuery =
            static_cast<xvecClusterIdType>(nprobe_to_use);
    fineSearchQuery.nearestClustersBufferHandle = clustersBuffer->handle();
    fineSearchQuery.useQueryQuantization = (qb_to_use > 0) ? 1 : 0;
    fineSearchQuery.queryBits = qb_to_use;
    fineSearchQuery.centeredQuantization = centered ? 1 : 0;
    fineSearchQuery._reserved = 0;

    // Execute fine search with timing
    xvecIvfRaBitQSearchTiming searchTiming{};
    xvecStatus status;
    {
        ScopedTimer t(search_ms);
        status = xvecIvfRaBitQSearchFineSearchOnly(
                ctx,
                muIndex_->handle(),
                &fineSearchQuery,
                resultsBuffer->handle(),
                &searchTiming);
    }

    FAISS_THROW_IF_NOT_FMT(
            status == XVEC_SUCCESS,
            "xvecIvfRaBitQSearchFineSearchOnly failed (status=%d)",
            static_cast<int>(status));

    // Copy results
    {
        ScopedTimer t(copy_ms);
        pxl::flushHostCache(resultsBuffer->data(), resultsBuffer->size());
        copyResultsToOutput_(
                resultsBuffer->data<xvecIvfRaBitQSearchResultFloat32>(),
                n,
                k,
                distances,
                labels);
    }

    auto us_to_ms = [](int64_t us) { return us / 1000.0; };

    std::cout << std::fixed << std::setprecision(2)
              << "[MuIndexIvfRabitq::search_preassigned] n=" << n
              << " k=" << k << " nprobe=" << nprobe_to_use
              << " qb=" << qb_to_use << " centered=" << centered << "\n"
              << "    buf         " << std::setw(10) << buf_ms << " ms\n"
              << "    fine_search " << std::setw(10) << search_ms << " ms\n"
              << "    copy        " << std::setw(10) << copy_ms << " ms\n"
              << "    total       " << std::setw(10) << total_timer.elapsedMs() << " ms\n"
              << "  [xvector]\n"
              << "    indexPrep   " << std::setw(10) << us_to_ms(searchTiming.indexPrepareUs) << " ms\n"
              << "    queryPrep   " << std::setw(10) << us_to_ms(searchTiming.queryPrepareUs) << " ms\n"
              << "    queryFlush  " << std::setw(10) << us_to_ms(searchTiming.queryFlushUs) << " ms\n"
              << "    kernel      " << std::setw(10) << us_to_ms(searchTiming.kernelExecutionUs) << " ms\n"
              << "    total       " << std::setw(10) << us_to_ms(searchTiming.totalUs) << " ms\n";
}

} // namespace faiss
