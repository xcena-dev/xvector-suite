/*
   Copyright (c) 2026 XCENA Inc.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

#pragma once

#include <chrono>

namespace faiss {

class ScopedTimer {
    using Clock = std::chrono::high_resolution_clock;
    Clock::time_point start_;
    double& elapsed_ms_;

   public:
    explicit ScopedTimer(double& elapsed_ms)
            : start_(Clock::now()), elapsed_ms_(elapsed_ms) {}

    ~ScopedTimer() {
        elapsed_ms_ =
                std::chrono::duration<double, std::milli>(Clock::now() - start_)
                        .count();
    }

    /// Read current elapsed time before destruction (e.g. for total timers)
    double elapsedMs() const {
        return std::chrono::duration<double, std::milli>(Clock::now() - start_)
                .count();
    }

    ScopedTimer(const ScopedTimer&) = delete;
    ScopedTimer& operator=(const ScopedTimer&) = delete;
};

} // namespace faiss
