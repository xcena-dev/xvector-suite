/*
   Copyright (c) 2026 XCENA Inc.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

#ifndef FAISS_MU_INDEX_IVF_FLAT_H
#define FAISS_MU_INDEX_IVF_FLAT_H

#include <faiss/IndexIVFFlat.h>
#include <faiss/mu/MuResources.h>
#include <xvector/xvec_types.h>
#include <xvector_cpp/xvec_buffer.hpp>
#include <xvector_cpp/xvec_ivf_flat_index.hpp>
#include <cstdint>
#include <memory>
#include <string>

// Forward declarations for xvector types
struct xvecExecutionContextTag;
struct xvecIvfFlatSearchResultFloat32;

namespace faiss {

/// IndexIVFFlat implementation for MU accelerator
///
/// This class wraps faiss::IndexIVFFlat and accelerates search operations
/// using the xvector MU device. Train and add operations fall back to
/// the CPU implementation.
struct MuIndexIvfFlat : IndexIVFFlat {
    /// Construct with quantizer, parameters, and shared resources
    MuIndexIvfFlat(
            std::shared_ptr<MuResources> resources,
            Index* quantizer,
            size_t d,
            size_t nlist);

    /// Construct from an existing CPU IndexIVFFlat with shared resources
    MuIndexIvfFlat(
            std::shared_ptr<MuResources> resources,
            const faiss::IndexIVFFlat* index);

    ~MuIndexIvfFlat() override;

    /// Sync the current index state to MU device
    /// Must be called after train() and add() before search()
    void syncToMuDevice();

    /// MU-accelerated search using fast FAISS quantizer for coarse search
    /// and xvector device for fine search
    void search(
            idx_t n,
            const float* x,
            idx_t k,
            float* distances,
            idx_t* labels,
            const SearchParameters* params = nullptr) const override;

    /// MU-accelerated search with preassigned cluster IDs
    /// This allows the coarse search to be done externally (e.g., by FAISS
    /// quantizer) and only perform fine search on the MU device
    void search_preassigned(
            idx_t n,
            const float* x,
            idx_t k,
            const idx_t* assign,
            const float* centroid_dis,
            float* distances,
            idx_t* labels,
            bool store_pairs,
            const IVFSearchParameters* params = nullptr,
            IndexIVFStats* stats = nullptr) const override;

    // TODO: Cache invalidation for add/train/reset

    /// MU parallel mode for fine search workload distribution.
    /// 0 = AUTO (recommended), 1 = QUERY_FIXED, 2 = CLUSTER_LIST_FIXED
    int mu_parallel_mode = 0;

    /// Get the shared MuResources
    std::shared_ptr<MuResources> getResources() const {
        return resources_;
    }

   protected:
    xvecDistanceType convertMetricType_() const;

    xvec::Buffer createQueryBuffer_(
            xvecExecutionContextTag* ctx,
            idx_t n,
            const float* x) const;

    xvec::Buffer createClustersBuffer_(
            xvecExecutionContextTag* ctx,
            idx_t n,
            size_t nprobe,
            const idx_t* assign) const;

    void copyResultsToOutput_(
            const xvecIvfFlatSearchResultFloat32* muResults,
            idx_t n,
            idx_t k,
            float* distances,
            idx_t* labels) const;

   protected:
    std::shared_ptr<MuResources> resources_;
    mutable std::optional<xvec::IvfFlatIndex> muIndex_;
};

} // namespace faiss

#endif
