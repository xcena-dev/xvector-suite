/*
   Copyright (c) 2026 XCENA Inc.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

#include <faiss/impl/FaissAssert.h>
#include <faiss/mu/MuResources.h>

#include <xvector/xvec_log.h>
#include <xvector_cpp/xvec_config.hpp>

#include <iostream>
#include <string>

namespace faiss {

namespace {

void defaultLogCallback(
        xvecLogLevel logLevel,
        const char* file,
        uint32_t line,
        const char* message,
        void* /* userData */) {
    std::cout << "[XVEC " << xvecGetLogLevelString(logLevel) << "] " << file
              << ':' << line << " - " << message << '\n';
}

} // namespace

MuResources::MuResources(const MuResourcesConfig& config) : config_(config) {
    FAISS_THROW_IF_NOT_MSG(
            !config_.modulePath.empty(),
            "MuResourcesConfig.modulePath must be specified");

    if (config_.enableDefaultLogSink) {
        xvecSetLogSink(defaultLogCallback, nullptr);
        // Use log level from ConfigManager
        auto& cm = xvec::host::ConfigManager::instance();
        uint32_t logLevel = cm.getHostLogLevel();
        if (logLevel > 0) {
            xvecSetLogLevel(static_cast<xvecLogLevel>(logLevel));
        }
    }

    context_.emplace(config_.deviceId, config_.modulePath);
    context_->setProperty("numSub", std::to_string(config_.numSub));
    context_->setProperty("taskCount", std::to_string(config_.taskCount));
    context_->setProperty(
            "deviceLogLevel", std::to_string(config_.deviceLogLevel));
}

MuResourcesConfig MuResourcesConfig::fromConfigManager() {
    auto& cm = xvec::host::ConfigManager::instance();

    MuResourcesConfig config;
    config.modulePath = cm.getMubinPath();
    config.deviceId = cm.getDeviceId();
    config.numSub = cm.getNumSub();
    config.taskCount = cm.getTaskCount();
    config.deviceLogLevel = cm.getDeviceLogLevel();
    config.enableDefaultLogSink = cm.isHostLogEnabled();
    return config;
}

std::shared_ptr<MuResources> makeMuResources() {
    return std::make_shared<MuResources>(
            MuResourcesConfig::fromConfigManager());
}

std::shared_ptr<MuResources> makeMuResources(const MuResourcesConfig& config) {
    return std::make_shared<MuResources>(config);
}

} // namespace faiss
