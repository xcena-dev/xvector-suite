/*
   Copyright (c) 2026 XCENA Inc.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

#pragma once

#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

/// Simple named-argument parser for benchmark binaries.
/// All parameters use explicit flags (no positional arguments).
///
/// Example:
///   ArgParser args("bench_ivf_flat",
///                  "Benchmark for IVFFlat: Original (CPU) vs MU");
///   args.addOption("--dataset", "-d", "Dataset name", "sift1m");
///   args.addFlag("--skip-cpu", "", "Skip CPU benchmark");
///   if (!args.parse(argc, argv)) return 1;
///   std::string ds = args.get("--dataset");
class ArgParser {
   public:
    ArgParser(std::string programName, std::string description)
            : programName_(std::move(programName)),
              description_(std::move(description)) {}

    /// Register a named option that takes a value.
    void addOption(
            const std::string& longName,
            const std::string& shortName,
            const std::string& help,
            const std::string& defaultValue = "") {
        options_.push_back({longName, shortName, help, defaultValue, false});
        if (!defaultValue.empty()) {
            values_[longName] = defaultValue;
        }
        if (!shortName.empty()) {
            shortToLong_[shortName] = longName;
        }
    }

    /// Register a boolean flag (no value).
    void addFlag(
            const std::string& longName,
            const std::string& shortName,
            const std::string& help) {
        options_.push_back({longName, shortName, help, "", true});
        values_[longName] = "0";
        if (!shortName.empty()) {
            shortToLong_[shortName] = longName;
        }
    }

    /// Parse argv.  Returns false on error (message already printed).
    bool parse(int argc, char** argv) {
        for (int i = 1; i < argc; i++) {
            std::string arg = argv[i];

            if (arg == "--help" || arg == "-h") {
                printHelp();
                std::exit(0);
            }

            // Resolve short name → long name
            auto s = shortToLong_.find(arg);
            const std::string& key =
                    (s != shortToLong_.end()) ? s->second : arg;

            auto* opt = findOption(key);
            if (!opt) {
                std::cerr << "Unknown option: " << arg << "\n\n";
                printHelp();
                return false;
            }

            if (opt->isFlag) {
                values_[key] = "1";
            } else {
                if (i + 1 >= argc) {
                    std::cerr << "Option " << arg << " requires a value\n";
                    return false;
                }
                values_[key] = argv[++i];
            }
        }
        return true;
    }

    // ---- accessors ----

    std::string get(const std::string& name) const {
        auto it = values_.find(name);
        return (it != values_.end()) ? it->second : "";
    }

    int getInt(const std::string& name) const {
        const std::string& v = get(name);
        if (v.empty())
            return 0;
        char* end = nullptr;
        long val = std::strtol(v.c_str(), &end, 10);
        if (end == v.c_str()) {
            std::cerr << "Invalid integer for " << name << ": " << v << "\n";
            std::exit(1);
        }
        return static_cast<int>(val);
    }

    size_t getSizeT(const std::string& name) const {
        const std::string& v = get(name);
        if (v.empty())
            return 0;
        char* end = nullptr;
        unsigned long val = std::strtoul(v.c_str(), &end, 10);
        if (end == v.c_str()) {
            std::cerr << "Invalid integer for " << name << ": " << v << "\n";
            std::exit(1);
        }
        return static_cast<size_t>(val);
    }

    bool getBool(const std::string& name) const {
        return get(name) == "1";
    }

    bool has(const std::string& name) const {
        auto it = values_.find(name);
        return it != values_.end() && !it->second.empty();
    }

    void printHelp() const {
        std::cout << description_ << "\n\n";
        std::cout << "Usage: " << programName_ << " [options]\n\n";
        std::cout << "Options:\n";
        for (const auto& opt : options_) {
            std::string names = "  " + opt.longName;
            if (!opt.shortName.empty()) {
                names += ", " + opt.shortName;
            }
            std::cout << std::left << std::setw(26) << names << opt.help;
            if (!opt.isFlag && !opt.defaultValue.empty()) {
                std::cout << " (default: " << opt.defaultValue << ")";
            }
            std::cout << "\n";
        }
        std::cout << std::left << std::setw(26) << "  --help, -h"
                  << "Show this help message\n";
    }

   private:
    struct Option {
        std::string longName;
        std::string shortName;
        std::string help;
        std::string defaultValue;
        bool isFlag;
    };

    Option* findOption(const std::string& name) {
        for (auto& opt : options_) {
            if (opt.longName == name)
                return &opt;
        }
        return nullptr;
    }

    std::string programName_;
    std::string description_;
    std::vector<Option> options_;
    std::unordered_map<std::string, std::string> values_;
    std::unordered_map<std::string, std::string> shortToLong_;
};
