/*
   Copyright (c) 2026 XCENA Inc.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

/**
 * Benchmark for IVFFlat: Original (CPU) vs MU-accelerated
 *
 * Run with --help to see all options.
 */

#include <cassert>
#include <cerrno>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <random>
#include <string>
#include <vector>

#include <iomanip>
#include <iostream>

#include <omp.h>
#include <sys/stat.h>

#include <faiss/IndexFlat.h>
#include <faiss/IndexIVFFlat.h>
#include <faiss/impl/FaissException.h>
#include <faiss/index_io.h>

#ifdef FAISS_ENABLE_MU
#include <faiss/mu/MuIndexIvfFlat.h>
#include <faiss/mu/MuResources.h>
#include <xvector/xvec_log.h>
#endif

using idx_t = faiss::idx_t;

#include "bench_args.h"
#include "power_monitor.h"

/*****************************************************
 * I/O functions for fvecs and ivecs
 *****************************************************/

float* fvecs_read(const char* fname, size_t* d_out, size_t* n_out) {
    FILE* f = fopen(fname, "r");
    if (!f) {
        std::cerr << "Could not open " << fname << ": " << std::strerror(errno)
                  << '\n';
        abort();
    }
    int d;
    fread(&d, 1, sizeof(int), f);
    assert((d > 0 && d < 1000000) || !"unreasonable dimension");
    fseek(f, 0, SEEK_SET);
    struct stat st;
    fstat(fileno(f), &st);
    size_t sz = st.st_size;
    assert(sz % ((d + 1) * 4) == 0 || !"weird file size");
    size_t n = sz / ((d + 1) * 4);

    *d_out = d;
    *n_out = n;
    float* x = new float[n * (d + 1)];
    size_t nr __attribute__((unused)) = fread(x, sizeof(float), n * (d + 1), f);
    assert(nr == n * (d + 1) || !"could not read whole file");

    // shift array to remove row headers
    for (size_t i = 0; i < n; i++)
        memmove(x + i * d, x + 1 + i * (d + 1), d * sizeof(*x));

    fclose(f);
    return x;
}

int* ivecs_read(const char* fname, size_t* d_out, size_t* n_out) {
    return (int*)fvecs_read(fname, d_out, n_out);
}

/*****************************************************
 * Timing utilities
 *****************************************************/

using Clock = std::chrono::high_resolution_clock;
using TimePoint = std::chrono::time_point<Clock>;

double elapsed_ms(TimePoint start, TimePoint end) {
    return std::chrono::duration<double, std::milli>(end - start).count();
}

/*****************************************************
 * Recall computation
 *****************************************************/

float compute_recall_at_k(
        const idx_t* results,
        const int* groundtruth,
        size_t nq,
        size_t k,
        size_t gt_k,
        int at_k) {
    size_t correct = 0;
    for (size_t i = 0; i < nq; i++) {
        for (int j = 0; j < at_k && j < (int)k; j++) {
            if (results[i * k + j] == groundtruth[i * gt_k]) {
                correct++;
                break;
            }
        }
    }
    return (float)correct / nq;
}

#ifdef FAISS_ENABLE_MU
void xvecLogCallback(
        xvecLogLevel logLevel,
        const char* file,
        uint32_t line,
        const char* message,
        void* /* userData */) {
    std::cout << "[XVEC " << xvecGetLogLevelString(logLevel) << "] " << file
              << ':' << line << " - " << message << '\n';
}
#endif

/*****************************************************
 * Estimated total data read
 *****************************************************/

struct BandwidthInfo {
    double totalDataGB;     // Total data scanned in GB
    size_t vectorsPerQuery; // Vectors scanned per query
};

BandwidthInfo calculateBandwidth(
        size_t ntotal,
        size_t nlist,
        size_t nprobe,
        size_t d,
        size_t nq) {
    BandwidthInfo info;
    size_t vectorsPerCluster = ntotal / nlist;
    info.vectorsPerQuery = nprobe * vectorsPerCluster;
    size_t bytesPerVector = d * sizeof(float);
    double totalBytes = (double)nq * info.vectorsPerQuery * bytesPerVector;
    info.totalDataGB = totalBytes / (1024.0 * 1024.0 * 1024.0);
    return info;
}

/*****************************************************
 * Benchmark functions
 *****************************************************/

struct BenchmarkResult {
    double searchTimeMs;
    float recall1;
    float recall10;
    float recall100;
    double qps;
    double gbps;       // GB/s bandwidth
    double avgWatts;   // Average power during search (0 if not measured)
    double qpsPerWatt; // QPS/W efficiency (0 if not measured)
};

BenchmarkResult benchmarkSearch(
        faiss::Index* index,
        const float* queries,
        size_t nq,
        size_t k,
        const int* groundtruth,
        size_t gt_k,
        double totalDataGB,
        int warmup_runs = 0,
        int bench_runs = 1,
        PowerMonitor* powerMonitor = nullptr) {
    std::vector<idx_t> I(nq * k);
    std::vector<float> D(nq * k);

    // Warmup
    for (int i = 0; i < warmup_runs; i++) {
        index->search(nq, queries, k, D.data(), I.data());
    }

    // Start power monitoring for the measured runs
    if (powerMonitor)
        powerMonitor->start();

    // Benchmark
    double total_time = 0;
    for (int i = 0; i < bench_runs; i++) {
        auto start = Clock::now();
        index->search(nq, queries, k, D.data(), I.data());
        auto end = Clock::now();
        total_time += elapsed_ms(start, end);
    }

    // Stop power monitoring
    if (powerMonitor)
        powerMonitor->stop();

    BenchmarkResult result;
    result.searchTimeMs = total_time / bench_runs;
    result.qps = (nq * 1000.0) / result.searchTimeMs;
    result.gbps = totalDataGB / (result.searchTimeMs / 1000.0);

    if (powerMonitor && powerMonitor->isAvailable() &&
        powerMonitor->getSampleCount() > 0) {
        result.avgWatts = powerMonitor->getAverageWatts();
        result.qpsPerWatt = result.qps / result.avgWatts;
    } else {
        result.avgWatts = 0;
        result.qpsPerWatt = 0;
    }

    if (groundtruth != nullptr && gt_k > 0) {
        result.recall1 =
                compute_recall_at_k(I.data(), groundtruth, nq, k, gt_k, 1);
        result.recall10 =
                compute_recall_at_k(I.data(), groundtruth, nq, k, gt_k, 10);
        result.recall100 =
                compute_recall_at_k(I.data(), groundtruth, nq, k, gt_k, 100);
    } else {
        result.recall1 = result.recall10 = result.recall100 = -1;
    }

    return result;
}

void printTableHeader(bool showPower) {
    std::cout << std::left << std::setw(20) << "Implementation" << " | "
              << std::setw(13) << "Search Time" << " | " << std::setw(12)
              << "Throughput" << " | " << std::setw(10) << "Bandwidth";
    if (showPower) {
        std::cout << " | " << std::setw(10) << "Power" << " | " << std::setw(12)
                  << "Efficiency";
    }
    std::cout << " | " << "Recall" << '\n';
    std::cout << "--------------------" << "-+-" << "-------------" << "-+-"
              << "------------" << "-+-" << "----------";
    if (showPower) {
        std::cout << "-+-" << "----------" << "-+-" << "------------";
    }
    std::cout << "-+-" << "-----------------------------------" << '\n';
}

void printBenchmarkResult(
        const char* name,
        const BenchmarkResult& result,
        bool showPower) {
    std::cout << std::left << std::setw(20) << name << " | " << std::right
              << std::setw(10) << std::fixed << std::setprecision(2)
              << result.searchTimeMs << " ms" << " | " << std::setw(8)
              << std::setprecision(0) << result.qps << " QPS" << " | "
              << std::setw(7) << std::setprecision(2) << result.gbps << " GB/s";
    if (showPower) {
        if (result.avgWatts > 0) {
            std::cout << " | " << std::setw(7) << std::setprecision(1)
                      << result.avgWatts << " W" << " | " << std::setw(8)
                      << std::setprecision(2) << result.qpsPerWatt << " QPS/W";
        } else {
            std::cout << " | " << std::setw(10) << "N/A" << " | "
                      << std::setw(12) << "N/A";
        }
    }
    if (result.recall1 >= 0) {
        std::cout << " | R@1=" << std::setprecision(4) << result.recall1
                  << " R@10=" << result.recall10
                  << " R@100=" << result.recall100;
    }
    std::cout << '\n';
}

int main(int argc, char** argv) {
    // Set OMP threads to avoid OpenBLAS issues
    omp_set_num_threads(64);

    // Parse arguments
    ArgParser args(
            "bench_ivf_flat",
            "Benchmark for IVFFlat: Original (CPU) vs MU-accelerated");
    args.addOption("--dataset", "-d", "Dataset name (for display)", "");
    args.addOption("--nprobe", "-p", "Number of probes", "16");
    args.addOption("--topk", "", "Number of results", "100");
    args.addOption("--index", "-i", "Index .faiss path");
    args.addOption("--query", "-q", "Query .fvecs path");
    args.addOption("--groundtruth-path", "-g", "Ground truth .ivecs path");
    args.addFlag(
            "--force-ip",
            "",
            "Force inner product metric (skips ground truth)");
    args.addOption(
            "--max-queries", "", "Limit or expand query count (0 = use all)");
    args.addFlag("--skip-cpu", "", "Skip CPU benchmark, run MU only");
    args.addFlag("--power", "", "Enable power monitoring (ipmitool dcmi)");
    args.addOption(
            "--power-interval", "", "Power sampling interval in ms", "500");
    args.addOption(
            "--random-queries",
            "",
            "Generate N random queries (0 = disabled)",
            "0");
    args.addOption(
            "--flat-parallel-mode",
            "",
            "MU parallel mode (0=AUTO, 1=QUERY_FIXED, 2=CLUSTER_LIST_FIXED)",
            "0");
    if (!args.parse(argc, argv))
        return 1;

    std::string dataset = args.get("--dataset");
    int nprobe = args.getInt("--nprobe");
    size_t k = args.getSizeT("--topk");
    std::string indexPath = args.get("--index");
    std::string queryPath = args.get("--query");
    std::string groundtruthPath = args.get("--groundtruth-path");
    bool forceInnerProduct = args.getBool("--force-ip");
    size_t maxNq = args.getSizeT("--max-queries"); // 0 means use all queries
    bool skipCpu = args.getBool("--skip-cpu");
    bool enablePower = args.getBool("--power");
    int powerInterval = args.getInt("--power-interval");
    size_t randomQueries = args.getSizeT("--random-queries");
    int flatParallelMode = args.getInt("--flat-parallel-mode");
    bool skipGroundTruth =
            forceInnerProduct || groundtruthPath.empty() || randomQueries > 0;

    std::cout << "=== IVFFlat Benchmark: Original vs MU ===" << '\n';
    std::cout << "Dataset: " << dataset << ", nprobe: " << nprobe
              << ", k: " << k << '\n';
    if (forceInnerProduct) {
        std::cout << "Force metric: INNER_PRODUCT (ground truth skipped)"
                  << '\n';
    }
    std::cout << '\n';

    // Load pre-trained index
    std::cout << "Loading index from: " << indexPath << '\n';
    std::unique_ptr<faiss::Index> baseIndex(
            faiss::read_index(indexPath.c_str()));
    faiss::IndexIVFFlat* cpuIndex =
            dynamic_cast<faiss::IndexIVFFlat*>(baseIndex.get());
    if (!cpuIndex) {
        std::cerr << "Failed to load index as IndexIVFFlat" << '\n';
        return 1;
    }

    std::cout << "Index loaded: d=" << (int)cpuIndex->d
              << ", ntotal=" << cpuIndex->ntotal
              << ", nlist=" << cpuIndex->nlist << ", metric="
              << (cpuIndex->metric_type == faiss::METRIC_L2 ? "L2" : "IP")
              << '\n';

    // Force inner product metric if requested
    if (forceInnerProduct) {
        cpuIndex->metric_type = faiss::METRIC_INNER_PRODUCT;
        std::cout << "Metric overridden to: INNER_PRODUCT" << '\n';
    }

    // Load or generate queries
    size_t d, nq;
    float* xq;
    if (randomQueries > 0) {
        d = cpuIndex->d;
        nq = randomQueries;
        std::cout << "Generating " << nq << " random queries (d=" << d << ")"
                  << '\n';
        xq = new float[nq * d];
        std::mt19937 rng(42);
        std::uniform_real_distribution<float> dist(0.0f, 1.0f);
        for (size_t i = 0; i < nq * d; i++) {
            xq[i] = dist(rng);
        }
    } else {
        std::cout << "Loading queries from: " << queryPath << '\n';
        xq = fvecs_read(queryPath.c_str(), &d, &nq);
        std::cout << "Queries loaded: nq=" << nq << ", d=" << d << '\n';
        assert(d == (size_t)cpuIndex->d || !"Query dimension mismatch");
    }

    // Adjust query count if --max-queries specified
    if (maxNq > 0 && maxNq != nq) {
        skipGroundTruth = true;
        if (maxNq <= nq) {
            std::cout << "Limiting queries: " << nq << " -> " << maxNq
                      << " (--max-queries)" << '\n';
            nq = maxNq;
        } else {
            std::cout << "Expanding queries: " << nq << " -> " << maxNq
                      << " (--max-queries, repeating)" << '\n';
            float* xq_expanded = new float[maxNq * d];
            for (size_t i = 0; i < maxNq; i++) {
                memcpy(xq_expanded + i * d,
                       xq + (i % nq) * d,
                       d * sizeof(float));
            }
            delete[] xq;
            xq = xq_expanded;
            nq = maxNq;
        }
    }

    // Load ground truth (optional, skip if using custom index)
    int* gt = nullptr;
    size_t gt_k = 0;
    if (!skipGroundTruth) {
        std::cout << "Loading ground truth from: " << groundtruthPath << '\n';
        size_t nq_gt;
        gt = ivecs_read(groundtruthPath.c_str(), &gt_k, &nq_gt);
        assert(nq_gt == nq || !"Ground truth count mismatch");
        std::cout << "Ground truth loaded: k=" << gt_k << '\n';
    } else {
        std::cout << "Ground truth: skipped" << '\n';
    }

    // Calculate bandwidth info
    BandwidthInfo bwInfo = calculateBandwidth(
            cpuIndex->ntotal, cpuIndex->nlist, nprobe, d, nq);
    std::cout << "\nEstimated total data read: " << std::fixed
              << std::setprecision(2) << bwInfo.totalDataGB << " GB total ("
              << std::setprecision(0) << (double)bwInfo.vectorsPerQuery
              << " vectors/query x " << nq << " queries x " << d * sizeof(float)
              << " bytes/vector)" << '\n';

    // Power monitor (optional)
    std::unique_ptr<PowerMonitor> powerMonitor;
    if (enablePower) {
        powerMonitor = std::make_unique<PowerMonitor>(powerInterval);
        std::cout << "\nPower monitoring enabled (interval=" << powerInterval
                  << "ms)" << '\n';
    }

    std::cout << '\n';

    // Benchmark Original (CPU)
    cpuIndex->nprobe = nprobe;
    BenchmarkResult cpuResult{};
    bool hasCpuResult = false;
    if (!skipCpu) {
        cpuResult = benchmarkSearch(
                cpuIndex,
                xq,
                nq,
                k,
                gt,
                gt_k,
                bwInfo.totalDataGB,
                0,
                1,
                powerMonitor.get());
        hasCpuResult = true;
        std::cout << "Original (CPU): " << std::fixed << std::setprecision(0)
                  << cpuResult.qps << " QPS (" << std::setprecision(2)
                  << cpuResult.searchTimeMs << " ms)" << '\n';
    } else {
        std::cout << "Original (CPU): SKIPPED" << '\n';
    }

    BenchmarkResult muResult{};
    bool hasMuResult = false;

#ifdef FAISS_ENABLE_MU
    // Set up xvector log sink
    xvecSetLogSink(xvecLogCallback, nullptr);

    // Create MU resources
    faiss::MuResourcesConfig resourcesConfig =
            faiss::MuResourcesConfig::fromConfigManager();

    const char* flatParallelModeNames[] = {
            "AUTO", "QUERY_FIXED", "CLUSTER_LIST_FIXED"};
    const char* flatParallelModeName =
            (flatParallelMode >= 0 && flatParallelMode <= 2)
            ? flatParallelModeNames[flatParallelMode]
            : "UNKNOWN";

    std::cout << '\n'
              << "Initializing MU device (deviceId=" << resourcesConfig.deviceId
              << ", numSub=" << resourcesConfig.numSub
              << ", taskCount=" << resourcesConfig.taskCount
              << ", flatParallelMode=" << flatParallelMode << " ["
              << flatParallelModeName << "])..." << '\n';
    try {
        auto resources = faiss::makeMuResources(resourcesConfig);

        // Create MU index from existing CPU index
        faiss::MuIndexIvfFlat muIndex(resources, cpuIndex);

        muIndex.nprobe = nprobe;
        muIndex.mu_parallel_mode = flatParallelMode;

        std::cout << "Syncing index to MU device..." << '\n';
        muIndex.syncToMuDevice();
        std::cout << "MU index ready" << '\n';

        // Benchmark MU
        muResult = benchmarkSearch(
                &muIndex,
                xq,
                nq,
                k,
                gt,
                gt_k,
                bwInfo.totalDataGB,
                0,
                1,
                powerMonitor.get());
        hasMuResult = true;
        std::cout << "MU Accelerated: " << std::fixed << std::setprecision(0)
                  << muResult.qps << " QPS (" << std::setprecision(2)
                  << muResult.searchTimeMs << " ms)" << '\n';
    } catch (const faiss::FaissException& e) {
        std::cerr << "MU initialization failed: " << e.what() << '\n';
        std::cerr << "Skipping MU benchmark." << '\n';
    }
#else
    std::cout << '\n'
              << "MU support not enabled (FAISS_ENABLE_MU not defined)" << '\n';
#endif

    // Print final summary table
    std::cout << '\n';
    printTableHeader(enablePower);
    if (hasCpuResult) {
        printBenchmarkResult("Original (CPU)", cpuResult, enablePower);
    } else {
        std::cout << std::left << std::setw(20) << "Original (CPU)" << " | "
                  << std::setw(13) << "SKIPPED" << " | " << std::setw(12) << "-"
                  << " | " << std::setw(10) << "-" << " | " << "-" << '\n';
    }
    if (hasMuResult) {
        printBenchmarkResult("MU Accelerated", muResult, enablePower);
    }
    if (hasCpuResult && hasMuResult) {
        std::cout << '\n'
                  << std::left << std::setw(20) << "MU vs CPU" << " | "
                  << std::right << std::setw(10) << std::fixed
                  << std::setprecision(2)
                  << cpuResult.searchTimeMs / muResult.searchTimeMs
                  << "x speedup" << " | " << muResult.gbps << " vs "
                  << cpuResult.gbps << " GB/s" << '\n';
    }

    // Cleanup
    delete[] xq;
    delete[] gt;

    return 0;
}