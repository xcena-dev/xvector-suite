/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

#pragma once

#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

/// Monitors system power consumption via `ipmitool dcmi power reading`.
///
/// Usage:
///   PowerMonitor monitor;
///   monitor.start();
///   // ... run benchmark ...
///   monitor.stop();
///   double avgW = monitor.getAverageWatts();
///
/// Requires sudo access to ipmitool. The sampling interval should be
/// >= 500ms since DCMI readings typically update every 1-2 seconds.
class PowerMonitor {
   public:
    explicit PowerMonitor(int intervalMs = 500)
            : intervalMs_(intervalMs), running_(false) {}

    ~PowerMonitor() {
        stop();
    }

    /// Start background power sampling.
    void start() {
        if (running_.load())
            return;

        // Verify ipmitool is accessible
        if (!checkIpmitool()) {
            std::cerr << "[Power] Warning: ipmitool not available or "
                         "requires sudo. Power monitoring disabled."
                      << '\n';
            available_ = false;
            return;
        }
        available_ = true;

        {
            std::lock_guard<std::mutex> lock(mutex_);
            samples_.clear();
        }
        running_.store(true);
        thread_ = std::thread(&PowerMonitor::sampleLoop, this);
    }

    /// Stop background power sampling.
    void stop() {
        if (!running_.load())
            return;
        running_.store(false);
        if (thread_.joinable()) {
            thread_.join();
        }
    }

    /// Returns true if ipmitool was available and sampling ran.
    bool isAvailable() const {
        return available_;
    }

    /// Get number of samples collected.
    size_t getSampleCount() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return samples_.size();
    }

    /// Get average power in watts over the sampling period.
    double getAverageWatts() const {
        std::lock_guard<std::mutex> lock(mutex_);
        if (samples_.empty())
            return 0.0;
        double sum = 0;
        for (double w : samples_)
            sum += w;
        return sum / samples_.size();
    }

    /// Get minimum power reading in watts.
    double getMinWatts() const {
        std::lock_guard<std::mutex> lock(mutex_);
        if (samples_.empty())
            return 0.0;
        double minW = samples_[0];
        for (double w : samples_)
            if (w < minW)
                minW = w;
        return minW;
    }

    /// Get maximum power reading in watts.
    double getMaxWatts() const {
        std::lock_guard<std::mutex> lock(mutex_);
        if (samples_.empty())
            return 0.0;
        double maxW = samples_[0];
        for (double w : samples_)
            if (w > maxW)
                maxW = w;
        return maxW;
    }

    /// Print a summary line of power readings.
    void printSummary() const {
        if (!available_ || getSampleCount() == 0) {
            std::cout << "[Power] No power data available" << '\n';
            return;
        }
        std::cout << "[Power] Avg=" << std::fixed << std::setprecision(1)
                  << getAverageWatts() << "W" << " Min=" << getMinWatts() << "W"
                  << " Max=" << getMaxWatts() << "W" << " (" << getSampleCount()
                  << " samples)" << '\n';
    }

   private:
    int intervalMs_;
    std::atomic<bool> running_;
    bool available_ = false;
    std::thread thread_;
    mutable std::mutex mutex_;
    std::vector<double> samples_;

    /// Check if ipmitool is accessible.
    bool checkIpmitool() {
        FILE* pipe = popen("sudo ipmitool dcmi power reading 2>/dev/null", "r");
        if (!pipe)
            return false;
        char buf[256];
        bool found = false;
        while (fgets(buf, sizeof(buf), pipe)) {
            if (strstr(buf, "Instantaneous power reading")) {
                found = true;
                break;
            }
        }
        pclose(pipe);
        return found;
    }

    /// Parse watts from ipmitool output line like:
    ///   "    Instantaneous power reading:                   234 Watts"
    static double parseWatts(const char* line) {
        const char* colon = strchr(line, ':');
        if (!colon)
            return -1;
        char* end = nullptr;
        double val = strtod(colon + 1, &end);
        if (end == colon + 1)
            return -1;
        return val;
    }

    /// Read current instantaneous power from ipmitool.
    double readPowerWatts() {
        FILE* pipe = popen("sudo ipmitool dcmi power reading 2>/dev/null", "r");
        if (!pipe)
            return -1;

        double watts = -1;
        char buf[256];
        while (fgets(buf, sizeof(buf), pipe)) {
            if (strstr(buf, "Instantaneous power reading")) {
                watts = parseWatts(buf);
                break;
            }
        }
        pclose(pipe);
        return watts;
    }

    /// Background thread: sample power at the configured interval.
    void sampleLoop() {
        while (running_.load()) {
            double watts = readPowerWatts();
            if (watts > 0) {
                std::lock_guard<std::mutex> lock(mutex_);
                samples_.push_back(watts);
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(intervalMs_));
        }
    }
};
