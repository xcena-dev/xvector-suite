/*
   Copyright (c) 2026 XCENA Inc.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

/**
 * Benchmark for IVFRaBitQ: CPU vs MU with query quantization (qb)
 *
 * Run with --help to see all options.
 */

#include <cassert>
#include <cerrno>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

#include <fcntl.h>
#include <omp.h>
#include <sys/stat.h>
#include <unistd.h>

#include <faiss/IndexFlat.h>
#include <faiss/IndexIVFRaBitQ.h>
#include <faiss/impl/FaissException.h>
#include <faiss/index_io.h>

#ifdef FAISS_ENABLE_MU
#include <faiss/mu/MuIndexIvfRabitq.h>
#include <faiss/mu/MuResources.h>
#include <xvector/xvec_log.h>
#endif

using idx_t = faiss::idx_t;

#include "bench_args.h"
#include "power_monitor.h"

/*****************************************************
 * I/O functions for fvecs and ivecs
 *****************************************************/

float* fvecs_read(const char* fname, size_t* d_out, size_t* n_out) {
    FILE* f = fopen(fname, "rb");
    if (!f) {
        std::cerr << "Could not open " << fname << ": " << std::strerror(errno)
                  << '\n';
        abort();
    }
    int d;
    size_t rd = fread(&d, 1, sizeof(int), f);
    assert(rd == sizeof(int) || !"could not read dimension header");
    assert((d > 0 && d < 1000000) || !"unreasonable dimension");
    fseek(f, 0, SEEK_SET);
    struct stat st;
    fstat(fileno(f), &st);
    size_t sz = st.st_size;
    assert(sz % ((d + 1) * 4) == 0 || !"weird file size");
    size_t n = sz / ((d + 1) * 4);

    *d_out = d;
    *n_out = n;
    float* x = new float[n * (d + 1)];
    size_t nr __attribute__((unused)) = fread(x, sizeof(float), n * (d + 1), f);
    assert(nr == n * (d + 1) || !"could not read whole file");

    // shift array to remove row headers
    for (size_t i = 0; i < n; i++)
        memmove(x + i * d, x + 1 + i * (d + 1), d * sizeof(*x));

    fclose(f);
    return x;
}

int* ivecs_read(const char* fname, size_t* d_out, size_t* n_out) {
    FILE* f = fopen(fname, "rb");
    if (!f) {
        std::cerr << "Could not open " << fname << ": " << std::strerror(errno)
                  << '\n';
        abort();
    }
    int d;
    size_t rd = fread(&d, 1, sizeof(int), f);
    assert(rd == sizeof(int) || !"could not read dimension header");
    assert((d > 0 && d < 1000000) || !"unreasonable dimension");
    fseek(f, 0, SEEK_SET);
    struct stat st;
    fstat(fileno(f), &st);
    size_t sz = st.st_size;
    assert(sz % ((d + 1) * 4) == 0 || !"weird file size");
    size_t n = sz / ((d + 1) * 4);

    *d_out = d;
    *n_out = n;
    int* x = new int[n * (d + 1)];
    size_t nr __attribute__((unused)) = fread(x, sizeof(int), n * (d + 1), f);
    assert(nr == n * (d + 1) || !"could not read whole file");

    // shift array to remove row headers
    for (size_t i = 0; i < n; i++)
        memmove(x + i * d, x + 1 + i * (d + 1), d * sizeof(*x));

    fclose(f);
    return x;
}

/*****************************************************
 * Timing utilities
 *****************************************************/

using Clock = std::chrono::high_resolution_clock;
using TimePoint = std::chrono::time_point<Clock>;

double elapsed_ms(TimePoint start, TimePoint end) {
    return std::chrono::duration<double, std::milli>(end - start).count();
}

/*****************************************************
 * Recall computation
 *
 * compute_1_recall_at_k: fraction of queries where the true nearest neighbor
 * (groundtruth[0]) is found within the top-K results. This is "1-recall@K",
 * a standard ANN benchmark metric (not "K-recall@K").
 *****************************************************/

float compute_1_recall_at_k(
        const idx_t* results,
        const int* groundtruth,
        size_t nq,
        size_t k,
        size_t gt_k,
        size_t at_k) {
    size_t n = std::min(at_k, k);
    size_t correct = 0;
    for (size_t i = 0; i < nq; i++) {
        for (size_t j = 0; j < n; j++) {
            if (results[i * k + j] == groundtruth[i * gt_k]) {
                correct++;
                break;
            }
        }
    }
    return (float)correct / nq;
}

#ifdef FAISS_ENABLE_MU
void xvecLogCallback(
        xvecLogLevel logLevel,
        const char* file,
        uint32_t line,
        const char* message,
        void* /* userData */) {
    std::cout << "[XVEC " << xvecGetLogLevelString(logLevel) << "] " << file
              << ':' << line << " - " << message << '\n';
}
#endif

/*****************************************************
 * Estimated total data read
 *****************************************************/

struct BandwidthInfo {
    double totalDataGB;     // Total data scanned in GB
    size_t vectorsPerQuery; // Vectors scanned per query
};

BandwidthInfo calculateBandwidth(
        size_t ntotal,
        size_t nlist,
        size_t nprobe,
        size_t code_size,
        size_t nq) {
    BandwidthInfo info;
    size_t vectorsPerCluster = ntotal / nlist;
    info.vectorsPerQuery = nprobe * vectorsPerCluster;
    // RaBitQ uses binary codes, not full float vectors
    size_t bytesPerVector = code_size;
    double totalBytes = (double)nq * info.vectorsPerQuery * bytesPerVector;
    info.totalDataGB = totalBytes / (1024.0 * 1024.0 * 1024.0);
    return info;
}

/*****************************************************
 * Benchmark functions
 *****************************************************/

struct BenchmarkResult {
    double searchTimeMs;
    float recall1;
    float recall10;
    float recall100;
    double qps;
    double gbps;       // GB/s bandwidth
    double avgWatts;   // Average power during search (0 if not measured)
    double qpsPerWatt; // QPS/W efficiency (0 if not measured)
};

BenchmarkResult benchmarkSearch(
        faiss::Index* index,
        const float* queries,
        size_t nq,
        size_t k,
        const int* groundtruth,
        size_t gt_k,
        double totalDataGB,
        const faiss::SearchParameters* params = nullptr,
        int warmup_runs = 0,
        int bench_runs = 1,
        PowerMonitor* powerMonitor = nullptr) {
    std::vector<idx_t> I(nq * k);
    std::vector<float> D(nq * k);

    // Warmup
    for (int i = 0; i < warmup_runs; i++) {
        index->search(nq, queries, k, D.data(), I.data(), params);
    }

    // Start power monitoring for the measured runs
    if (powerMonitor)
        powerMonitor->start();

    // Benchmark
    double total_time = 0;
    for (int i = 0; i < bench_runs; i++) {
        auto start = Clock::now();
        index->search(nq, queries, k, D.data(), I.data(), params);
        auto end = Clock::now();
        total_time += elapsed_ms(start, end);
    }

    // Stop power monitoring
    if (powerMonitor)
        powerMonitor->stop();

    BenchmarkResult result;
    result.searchTimeMs = total_time / bench_runs;
    result.qps = (nq * 1000.0) / result.searchTimeMs;
    result.gbps = totalDataGB / (result.searchTimeMs / 1000.0);

    if (powerMonitor && powerMonitor->isAvailable() &&
        powerMonitor->getSampleCount() > 0) {
        result.avgWatts = powerMonitor->getAverageWatts();
        result.qpsPerWatt = result.qps / result.avgWatts;
    } else {
        result.avgWatts = 0;
        result.qpsPerWatt = 0;
    }

    if (groundtruth != nullptr && gt_k > 0) {
        result.recall1 =
                compute_1_recall_at_k(I.data(), groundtruth, nq, k, gt_k, 1);
        result.recall10 =
                compute_1_recall_at_k(I.data(), groundtruth, nq, k, gt_k, 10);
        result.recall100 =
                compute_1_recall_at_k(I.data(), groundtruth, nq, k, gt_k, 100);
    } else {
        result.recall1 = result.recall10 = result.recall100 = -1;
    }

    return result;
}

struct LabeledResult {
    std::string label;
    BenchmarkResult result;
    std::string timing; // captured timing breakdown from MU
};

void printTableHeader(bool showPower) {
    std::cout << std::left << std::setw(20) << "Implementation" << " | "
              << std::setw(13) << "Search Time" << " | " << std::setw(12)
              << "Throughput" << " | " << std::setw(10) << "Bandwidth";
    if (showPower) {
        std::cout << " | " << std::setw(10) << "Power" << " | " << std::setw(12)
                  << "Efficiency";
    }
    std::cout << " | " << "Recall" << '\n';
    std::cout << "--------------------" << "-+-" << "-------------" << "-+-"
              << "------------" << "-+-" << "----------";
    if (showPower) {
        std::cout << "-+-" << "----------" << "-+-" << "------------";
    }
    std::cout << "-+-" << "-----------------------------------" << '\n';
}

void printBenchmarkResult(
        const char* name,
        const BenchmarkResult& result,
        bool showPower) {
    std::cout << std::left << std::setw(20) << name << " | " << std::right
              << std::setw(10) << std::fixed << std::setprecision(2)
              << result.searchTimeMs << " ms" << " | " << std::setw(8)
              << std::setprecision(0) << result.qps << " QPS" << " | "
              << std::setw(7) << std::setprecision(2) << result.gbps << " GB/s";
    if (showPower) {
        if (result.avgWatts > 0) {
            std::cout << " | " << std::setw(7) << std::setprecision(1)
                      << result.avgWatts << " W" << " | " << std::setw(8)
                      << std::setprecision(2) << result.qpsPerWatt << " QPS/W";
        } else {
            std::cout << " | " << std::setw(10) << "N/A" << " | "
                      << std::setw(12) << "N/A";
        }
    }
    if (result.recall1 >= 0) {
        std::cout << " | 1-R@1=" << std::setprecision(4) << result.recall1
                  << " 1-R@10=" << result.recall10
                  << " 1-R@100=" << result.recall100;
    }
    std::cout << '\n';
}

void printResultsTable(
        const char* title,
        const std::vector<LabeledResult>& results,
        bool showPower) {
    std::cout << "\n--- " << title << " ---" << '\n';
    printTableHeader(showPower);
    for (const auto& r : results) {
        printBenchmarkResult(r.label.c_str(), r.result, showPower);
        if (!r.timing.empty()) {
            std::cout << r.timing;
        }
    }
}

// RAII stdout capture: redirects stdout to a temp file, restores on
// destruction. After destruction, call extractTimingLines() to get timing info.
static const char* kCaptureFile = "/tmp/bench_ivf_rabitq_capture.txt";

struct CaptureStdout {
    int savedFd;
    CaptureStdout() {
        fflush(stdout);
        savedFd = dup(STDOUT_FILENO);
        int fd = open(kCaptureFile, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        dup2(fd, STDOUT_FILENO);
        close(fd);
    }
    ~CaptureStdout() {
        fflush(stdout);
        dup2(savedFd, STDOUT_FILENO);
        close(savedFd);
    }
};

std::string extractTimingLines() {
    std::string result;
    FILE* f = fopen(kCaptureFile, "r");
    if (!f)
        return result;
    char line[1024];
    while (fgets(line, sizeof(line), f)) {
        std::string s(line);
        if (s.find("[xvector timing]") != std::string::npos ||
            s.find("search_preassigned]") != std::string::npos ||
            s.find("::search]") != std::string::npos) {
            result += "  " + s;
        }
    }
    fclose(f);
    return result;
}

int main(int argc, char** argv) {
    // Set OMP threads to avoid OpenBLAS issues
    omp_set_num_threads(64);

    // Parse arguments
    ArgParser args(
            "bench_ivf_rabitq",
            "Benchmark for IVFRaBitQ: CPU vs MU with query quantization (qb)");
    args.addOption("--dataset", "-d", "Dataset name (for display)", "");
    args.addOption("--nprobe", "-p", "Number of probes", "16");
    args.addOption("--topk", "", "Number of results", "100");
    args.addOption("--index", "-i", "Index .faiss path");
    args.addOption("--query", "-q", "Query .fvecs path");
    args.addOption("--groundtruth-path", "-g", "Ground truth .ivecs path");
    args.addOption(
            "--max-queries", "", "Limit or expand query count (0 = use all)");
    args.addOption(
            "--rabitq-qb",
            "",
            "Comma-separated qb values to test (e.g. 0,4,8)",
            "0-8");
    args.addFlag("--skip-cpu", "", "Skip CPU benchmark, run MU only");
    args.addFlag("--rabitq-centered", "", "Enable centered quantization");
    args.addFlag("--power", "", "Enable power monitoring (ipmitool dcmi)");
    args.addOption(
            "--power-interval", "", "Power sampling interval in ms", "500");
    if (!args.parse(argc, argv))
        return 1;

    std::string dataset = args.get("--dataset");
    int nprobe = args.getInt("--nprobe");
    size_t k = args.getSizeT("--topk");
    std::string indexPath = args.get("--index");
    std::string queryPath = args.get("--query");
    std::string groundtruthPath = args.get("--groundtruth-path");
    size_t maxNq = args.getSizeT("--max-queries"); // 0 means use all queries
    bool skipCpu = args.getBool("--skip-cpu");
    bool centered = args.getBool("--rabitq-centered");

    // Parse --rabitq-qb: "0-8" means all (0..8), otherwise comma-separated
    // values
    std::vector<int> qbValues;
    {
        std::string qbStr = args.get("--rabitq-qb");
        if (qbStr == "0-8") {
            for (int i = 0; i <= 8; i++)
                qbValues.push_back(i);
        } else {
            std::istringstream ss(qbStr);
            std::string token;
            while (std::getline(ss, token, ',')) {
                int v = std::atoi(token.c_str());
                if (v < 0 || v > 8) {
                    std::cerr << "Invalid qb value: " << token
                              << " (must be 0-8)\n";
                    return 1;
                }
                qbValues.push_back(v);
            }
        }
        if (qbValues.empty()) {
            std::cerr << "No qb values specified\n";
            return 1;
        }
    }
    bool enablePower = args.getBool("--power");
    int powerInterval = args.getInt("--power-interval");
    bool skipGroundTruth = groundtruthPath.empty();

    std::cout << "=== IVFRaBitQ Benchmark ===" << '\n';
    std::cout << "Dataset: " << dataset << ", nprobe: " << nprobe
              << ", k: " << k << ", centered: " << (centered ? "true" : "false")
              << ", qb: " << args.get("--rabitq-qb") << '\n';
    std::cout << '\n';

    // Load pre-trained index
    std::cout << "Loading index from: " << indexPath << '\n';
    std::unique_ptr<faiss::Index> baseIndex(
            faiss::read_index(indexPath.c_str()));
    faiss::IndexIVFRaBitQ* cpuIndex =
            dynamic_cast<faiss::IndexIVFRaBitQ*>(baseIndex.get());
    if (!cpuIndex) {
        std::cerr << "Failed to load index as IndexIVFRaBitQ\n";
        return 1;
    }

    std::cout << "Index loaded: d=" << (int)cpuIndex->d
              << ", ntotal=" << cpuIndex->ntotal
              << ", nlist=" << cpuIndex->nlist
              << ", code_size=" << cpuIndex->code_size << ", metric="
              << (cpuIndex->metric_type == faiss::METRIC_L2 ? "L2" : "IP")
              << '\n';

    // Load queries
    std::cout << "Loading queries from: " << queryPath << '\n';
    size_t d, nq;
    float* xq = fvecs_read(queryPath.c_str(), &d, &nq);

    std::cout << "Queries loaded: nq=" << nq << ", d=" << d << '\n';
    assert(d == (size_t)cpuIndex->d || !"Query dimension mismatch");

    // Adjust query count if --max-queries specified
    if (maxNq > 0 && maxNq != nq) {
        skipGroundTruth = true;
        if (maxNq <= nq) {
            std::cout << "Limiting queries: " << nq << " -> " << maxNq
                      << " (--max-queries)" << '\n';
            nq = maxNq;
        } else {
            std::cout << "Expanding queries: " << nq << " -> " << maxNq
                      << " (--max-queries, repeating)" << '\n';
            float* xq_expanded = new float[maxNq * d];
            for (size_t i = 0; i < maxNq; i++) {
                memcpy(xq_expanded + i * d,
                       xq + (i % nq) * d,
                       d * sizeof(float));
            }
            delete[] xq;
            xq = xq_expanded;
            nq = maxNq;
        }
    }

    // Load ground truth
    int* gt = nullptr;
    size_t gt_k = 0;
    if (!skipGroundTruth) {
        std::cout << "Loading ground truth from: " << groundtruthPath << '\n';
        size_t nq_gt;
        gt = ivecs_read(groundtruthPath.c_str(), &gt_k, &nq_gt);
        assert(nq_gt == nq || !"Ground truth count mismatch");
        std::cout << "Ground truth loaded: k=" << gt_k << '\n';
    } else {
        std::cout << "Ground truth: skipped" << '\n';
    }

    // Calculate bandwidth info
    BandwidthInfo bwInfo = calculateBandwidth(
            cpuIndex->ntotal, cpuIndex->nlist, nprobe, cpuIndex->code_size, nq);
    std::cout << "\nEstimated total data read: " << std::fixed
              << std::setprecision(2) << bwInfo.totalDataGB << " GB total ("
              << std::setprecision(0) << (double)bwInfo.vectorsPerQuery
              << " vectors/query x " << nq << " queries x "
              << cpuIndex->code_size << " bytes/vector)" << '\n';

    cpuIndex->nprobe = nprobe;

    // Power monitor (optional)
    std::unique_ptr<PowerMonitor> powerMonitor;
    if (enablePower) {
        powerMonitor = std::make_unique<PowerMonitor>(powerInterval);
        std::cout << "\nPower monitoring enabled (interval=" << powerInterval
                  << "ms)" << '\n';
    }

    // =========================================================
    // CPU Benchmark
    // =========================================================
    std::vector<LabeledResult> cpuResults;
    if (!skipCpu) {
        std::cout << "\nRunning CPU benchmark..." << '\n';
        for (int qb : qbValues) {
            faiss::IVFRaBitQSearchParameters params;
            params.nprobe = nprobe;
            params.qb = qb;
            params.centered = centered;

            std::string label = "CPU qb=" + std::to_string(qb);

            BenchmarkResult result = benchmarkSearch(
                    cpuIndex,
                    xq,
                    nq,
                    k,
                    gt,
                    gt_k,
                    bwInfo.totalDataGB,
                    &params,
                    1 /* warmup */,
                    3 /* bench_runs */,
                    powerMonitor.get());
            cpuResults.push_back({label, result, {}});
            std::cout << "  " << label << " done (" << std::fixed
                      << std::setprecision(2) << result.searchTimeMs << " ms)"
                      << '\n';
        }
    }

    // =========================================================
    // MU Benchmark
    // =========================================================
    std::vector<LabeledResult> muResults;
#ifdef FAISS_ENABLE_MU
    {
        xvecSetLogSink(xvecLogCallback, nullptr);

        faiss::MuResourcesConfig resourcesConfig =
                faiss::MuResourcesConfig::fromConfigManager();

        std::cout << "\nInitializing MU device (deviceId="
                  << resourcesConfig.deviceId
                  << ", numSub=" << resourcesConfig.numSub
                  << ", taskCount=" << resourcesConfig.taskCount << ")..."
                  << '\n';
        try {
            auto resources = faiss::makeMuResources(resourcesConfig);

            faiss::MuIndexIvfRabitq muIndex(resources, cpuIndex);
            muIndex.nprobe = nprobe;

            std::cout << "Syncing index to MU device..." << '\n';
            muIndex.syncToMuDevice();
            std::cout << "MU index ready" << '\n';

            std::cout << "Running MU benchmark..." << '\n';
            for (int qb : qbValues) {
                faiss::IVFRaBitQSearchParameters params;
                params.nprobe = nprobe;
                params.qb = qb;
                params.centered = false;

                std::string label = "MU qb=" + std::to_string(qb);

                BenchmarkResult result = benchmarkSearch(
                        &muIndex,
                        xq,
                        nq,
                        k,
                        gt,
                        gt_k,
                        bwInfo.totalDataGB,
                        &params,
                        0 /* warmup */,
                        1 /* bench_runs */,
                        powerMonitor.get());
                muResults.push_back({label, result, {}});
                std::cout << "  " << label << " done (" << std::fixed
                          << std::setprecision(2) << result.searchTimeMs
                          << " ms)" << '\n';
            }
        } catch (const faiss::FaissException& e) {
            std::cerr << "MU initialization failed: " << e.what() << '\n';
            std::cerr << "Skipping MU benchmark." << '\n';
        }
    }
#else
    std::cout << "\nMU support not enabled (FAISS_ENABLE_MU not defined)"
              << '\n';
#endif

    // =========================================================
    // Print summary
    // =========================================================
    std::cout << '\n';
    std::cout << "========================================================="
              << '\n';
    std::cout << "  Summary: " << dataset << ", nprobe=" << nprobe
              << ", k=" << k << '\n';
    std::cout << "========================================================="
              << '\n';

    if (!cpuResults.empty()) {
        printResultsTable("CPU Results", cpuResults, enablePower);
    }
    if (!muResults.empty()) {
        printResultsTable("MU Results", muResults, enablePower);
    }

    // Cleanup
    delete[] xq;
    delete[] gt;

    return 0;
}
