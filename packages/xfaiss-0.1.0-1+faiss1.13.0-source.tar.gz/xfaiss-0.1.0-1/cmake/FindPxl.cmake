# Copyright (c) 2026 XCENA Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Findpxl.cmake
#
# Find the pxl library (part of xflare)
#
# IMPORTED Targets:
#   pxl::pxl - The pxl shared library
#
# Variables:
#   PXL_FOUND - True if pxl was found
#   PXL_INCLUDE_DIRS - Include directories (empty for pxl)
#   PXL_LIBRARIES - The pxl library

# Allow user to specify pxl location
set(PXL_ROOT "/usr/local" CACHE PATH "Root directory of pxl installation")

# Find the header
find_path(PXL_INCLUDE_DIR
    NAMES pxl/pxl.hpp
    HINTS
        ${PXL_ROOT}/include
        /usr/local/include
    PATH_SUFFIXES include
)

# Find the library
find_library(PXL_LIBRARY
    NAMES pxl
    HINTS
        ${PXL_ROOT}/lib
        /usr/local/lib
    PATH_SUFFIXES lib lib64
)

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(pxl
    REQUIRED_VARS PXL_LIBRARY PXL_INCLUDE_DIR
)

if(pxl_FOUND AND NOT TARGET pxl::pxl)
    add_library(pxl::pxl SHARED IMPORTED)
    set_target_properties(pxl::pxl PROPERTIES
        IMPORTED_LOCATION "${PXL_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${PXL_INCLUDE_DIR}"
    )
endif()

mark_as_advanced(PXL_LIBRARY)
